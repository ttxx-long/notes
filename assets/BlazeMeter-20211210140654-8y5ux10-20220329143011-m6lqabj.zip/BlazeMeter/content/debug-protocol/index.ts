import {Application} from './application';

new Application().run();
