export const DEBUGGER_PING_V2 = 'debuggerPing.v2';
export const DEBUGGER_PONG_V2 = 'debuggerPong.v2';
export const REQUEST = 'request';

export const SCRIPTLESS_START_RECORDING = 'scriptless/start-recording';
