import React from 'react';

const SubHeader = () => (
    <div className='bzm-options-static'>
        <span className='options-name'>Options</span>
    </div>
);

export default SubHeader;
